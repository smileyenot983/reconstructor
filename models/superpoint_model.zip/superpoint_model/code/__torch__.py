class SuperPointNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  relu : __torch__.torch.nn.modules.activation.ReLU
  pool : __torch__.torch.nn.modules.pooling.MaxPool2d
  conv1a : __torch__.torch.nn.modules.conv.Conv2d
  conv1b : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  conv2a : __torch__.torch.nn.modules.conv.___torch_mangle_1.Conv2d
  conv2b : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  conv3a : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  conv3b : __torch__.torch.nn.modules.conv.___torch_mangle_4.Conv2d
  conv4a : __torch__.torch.nn.modules.conv.___torch_mangle_5.Conv2d
  conv4b : __torch__.torch.nn.modules.conv.___torch_mangle_6.Conv2d
  convPa : __torch__.torch.nn.modules.conv.___torch_mangle_7.Conv2d
  convPb : __torch__.torch.nn.modules.conv.___torch_mangle_8.Conv2d
  convDa : __torch__.torch.nn.modules.conv.___torch_mangle_9.Conv2d
  convDb : __torch__.torch.nn.modules.conv.___torch_mangle_10.Conv2d
  def forward(self: __torch__.SuperPointNet,
    x: Tensor) -> Tuple[Tensor, Tensor]:
    convDb = self.convDb
    convDa = self.convDa
    convPb = self.convPb
    convPa = self.convPa
    conv4b = self.conv4b
    conv4a = self.conv4a
    conv3b = self.conv3b
    conv3a = self.conv3a
    conv2b = self.conv2b
    conv2a = self.conv2a
    pool = self.pool
    conv1b = self.conv1b
    relu = self.relu
    conv1a = self.conv1a
    _0 = (relu).forward((conv1a).forward(x, ), )
    _1 = (relu).forward1((conv1b).forward(_0, ), )
    _2 = (conv2a).forward((pool).forward(_1, ), )
    _3 = (conv2b).forward((relu).forward2(_2, ), )
    _4 = (pool).forward1((relu).forward3(_3, ), )
    _5 = (relu).forward4((conv3a).forward(_4, ), )
    _6 = (relu).forward5((conv3b).forward(_5, ), )
    _7 = (conv4a).forward((pool).forward2(_6, ), )
    _8 = (conv4b).forward((relu).forward6(_7, ), )
    _9 = (relu).forward7(_8, )
    _10 = (relu).forward8((convPa).forward(_9, ), )
    _11 = (convPb).forward(_10, )
    _12 = (relu).forward9((convDa).forward(_9, ), )
    _13 = (convDb).forward(_12, )
    dn = torch.norm(_13, 2, [1])
    _14 = torch.div(_13, torch.unsqueeze(dn, 1))
    return (_11, _14)

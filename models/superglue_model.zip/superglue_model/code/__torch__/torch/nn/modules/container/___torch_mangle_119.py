class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.conv.___torch_mangle_116.Conv1d
  __annotations__["1"] = __torch__.torch.nn.modules.conv.___torch_mangle_117.Conv1d
  __annotations__["2"] = __torch__.torch.nn.modules.conv.___torch_mangle_118.Conv1d

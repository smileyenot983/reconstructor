class Conv1d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_106.Conv1d,
    value: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _0 = torch._convolution(value, weight, bias, [1], [0], [1], False, [0], 1, False, False, True, True)
    return _0
  def forward1(self: __torch__.torch.nn.modules.conv.___torch_mangle_106.Conv1d,
    value: Tensor) -> Tensor:
    bias = self.bias
    weight = self.weight
    _1 = torch._convolution(value, weight, bias, [1], [0], [1], False, [0], 1, False, False, True, True)
    return _1

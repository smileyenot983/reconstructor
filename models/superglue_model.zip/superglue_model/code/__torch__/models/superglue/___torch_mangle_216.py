class MultiHeadedAttention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  merge : __torch__.torch.nn.modules.conv.___torch_mangle_211.Conv1d
  proj : __torch__.torch.nn.modules.container.___torch_mangle_215.ModuleList
  def forward(self: __torch__.models.superglue.___torch_mangle_216.MultiHeadedAttention,
    query: Tensor,
    input: Tensor) -> Tensor:
    merge = self.merge
    proj = self.proj
    _2 = getattr(proj, "2")
    proj0 = self.proj
    _1 = getattr(proj0, "1")
    proj1 = self.proj
    _0 = getattr(proj1, "0")
    batch_dim = ops.prim.NumToTensor(torch.size(query, 0))
    _3 = int(batch_dim)
    _4 = int(batch_dim)
    _5 = int(batch_dim)
    _6 = int(batch_dim)
    query0 = torch.view((_0).forward(query, ), [_6, 64, 4, -1])
    _7 = torch.view((_1).forward(input, ), [_5, 64, 4, -1])
    _8 = torch.view((_2).forward(input, ), [_4, 64, 4, -1])
    _9 = ops.prim.NumToTensor(torch.size(query0, 1))
    _10 = torch.einsum("bdhn,bdhm->bhnm", [query0, _7])
    input0 = torch.div(_10, torch.pow(_9, 0.5))
    x = torch.einsum("bhnm,bdhm->bdhn", [torch.softmax(input0, -1), _8])
    input1 = torch.view(torch.contiguous(x), [_3, 256, -1])
    return (merge).forward(input1, )
  def forward1(self: __torch__.models.superglue.___torch_mangle_216.MultiHeadedAttention,
    input: Tensor,
    query: Tensor) -> Tensor:
    merge = self.merge
    proj = self.proj
    _2 = getattr(proj, "2")
    proj2 = self.proj
    _1 = getattr(proj2, "1")
    proj3 = self.proj
    _0 = getattr(proj3, "0")
    batch_dim = ops.prim.NumToTensor(torch.size(input, 0))
    _8 = int(batch_dim)
    _9 = int(batch_dim)
    _10 = int(batch_dim)
    _11 = int(batch_dim)
    query1 = torch.view((_0).forward1(input, ), [_11, 64, 4, -1])
    _12 = torch.view((_1).forward1(query, ), [_10, 64, 4, -1])
    _13 = torch.view((_2).forward1(query, ), [_9, 64, 4, -1])
    _14 = ops.prim.NumToTensor(torch.size(query1, 1))
    _15 = torch.einsum("bdhn,bdhm->bhnm", [query1, _12])
    input2 = torch.div(_15, torch.pow(_14, 0.5))
    x = torch.einsum("bhnm,bdhm->bdhn", [torch.softmax(input2, -1), _13])
    input3 = torch.view(torch.contiguous(x), [_8, 256, -1])
    return (merge).forward1(input3, )

class AttentionalPropagation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  attn : __torch__.models.superglue.___torch_mangle_36.MultiHeadedAttention
  mlp : __torch__.torch.nn.modules.container.___torch_mangle_41.Sequential
  def forward(self: __torch__.models.superglue.___torch_mangle_42.AttentionalPropagation,
    value: Tensor) -> Tensor:
    mlp = self.mlp
    attn = self.attn
    input = torch.cat([value, (attn).forward(value, )], 1)
    return (mlp).forward(input, )
  def forward1(self: __torch__.models.superglue.___torch_mangle_42.AttentionalPropagation,
    value: Tensor) -> Tensor:
    mlp = self.mlp
    attn = self.attn
    input = torch.cat([value, (attn).forward1(value, )], 1)
    return (mlp).forward1(input, )

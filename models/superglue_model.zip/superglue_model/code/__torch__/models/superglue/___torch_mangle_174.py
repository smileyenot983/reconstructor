class AttentionalPropagation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  attn : __torch__.models.superglue.___torch_mangle_168.MultiHeadedAttention
  mlp : __torch__.torch.nn.modules.container.___torch_mangle_173.Sequential
  def forward(self: __torch__.models.superglue.___torch_mangle_174.AttentionalPropagation,
    query: Tensor,
    input: Tensor) -> Tensor:
    mlp = self.mlp
    attn = self.attn
    _0 = [query, (attn).forward(query, input, )]
    input0 = torch.cat(_0, 1)
    return (mlp).forward(input0, )
  def forward1(self: __torch__.models.superglue.___torch_mangle_174.AttentionalPropagation,
    input: Tensor,
    query: Tensor) -> Tensor:
    mlp = self.mlp
    attn = self.attn
    _1 = [input, (attn).forward1(input, query, )]
    input1 = torch.cat(_1, 1)
    return (mlp).forward1(input1, )

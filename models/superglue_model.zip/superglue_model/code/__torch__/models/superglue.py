class SuperGlue(Module):
  __parameters__ = ["bin_score", ]
  __buffers__ = []
  bin_score : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  kenc : __torch__.models.superglue.KeypointEncoder
  gnn : __torch__.models.superglue.AttentionalGNN
  final_proj : __torch__.torch.nn.modules.conv.___torch_mangle_224.Conv1d
  def forward(self: __torch__.models.superglue.SuperGlue,
    keypoints0: Tensor,
    keypoints1: Tensor,
    descriptors0: Tensor,
    descriptors1: Tensor,
    scores0: Tensor,
    scores1: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    bin_score = self.bin_score
    final_proj = self.final_proj
    gnn = self.gnn
    kenc = self.kenc
    _0 = (kenc).forward(keypoints0, scores0, )
    value = torch.add(descriptors0, _0)
    _1 = (kenc).forward1(keypoints1, scores1, )
    value0 = torch.add(descriptors1, _1)
    _2, _3, = (gnn).forward(value, value0, )
    _4 = [(final_proj).forward(_2, ), (final_proj).forward1(_3, )]
    scores = torch.einsum("bdn,bdm->bnm", _4)
    scores2 = torch.div(scores, CONSTANTS.c0)
    b = ops.prim.NumToTensor(torch.size(scores2, 0))
    _5 = int(b)
    _6 = int(b)
    _7 = int(b)
    _8 = int(b)
    _9 = int(b)
    m = ops.prim.NumToTensor(torch.size(scores2, 1))
    _10 = int(m)
    _11 = int(m)
    n = ops.prim.NumToTensor(torch.size(scores2, 2))
    _12 = int(n)
    _13 = int(n)
    _14 = torch.to(CONSTANTS.c1, torch.device("cpu"), 6)
    one = torch.detach(_14)
    ms = torch.to(torch.mul(m, one), torch.device("cpu"), 6)
    ns = torch.to(torch.mul(n, one), torch.device("cpu"), 6)
    bins0 = torch.expand(bin_score, [_9, _11, 1])
    bins1 = torch.expand(bin_score, [_8, 1, _13])
    alpha = torch.expand(bin_score, [_7, 1, 1])
    _15 = [torch.cat([scores2, bins0], -1), torch.cat([bins1, alpha], -1)]
    Z = torch.cat(_15, 1)
    norm = torch.neg(torch.log(torch.add(ms, ns)))
    _16 = torch.expand(norm, [_10])
    _17 = torch.add(torch.unsqueeze(torch.log(ns), 0), norm)
    log_mu = torch.cat([_16, _17])
    _18 = torch.expand(norm, [_12])
    _19 = torch.add(torch.unsqueeze(torch.log(ms), 0), norm)
    log_nu = torch.cat([_18, _19])
    log_mu0 = torch.expand(torch.unsqueeze(log_mu, 0), [_6, -1])
    log_nu0 = torch.expand(torch.unsqueeze(log_nu, 0), [_5, -1])
    v = torch.zeros_like(log_nu0, dtype=6, layout=0, device=torch.device("cpu"), pin_memory=False)
    _20 = torch.logsumexp(torch.add(Z, torch.unsqueeze(v, 1)), [2])
    u = torch.sub(log_mu0, _20)
    _21 = torch.logsumexp(torch.add(Z, torch.unsqueeze(u, 2)), [1])
    v0 = torch.sub(log_nu0, _21)
    _22 = torch.add(Z, torch.unsqueeze(v0, 1))
    u0 = torch.sub(log_mu0, torch.logsumexp(_22, [2]))
    _23 = torch.add(Z, torch.unsqueeze(u0, 2))
    v1 = torch.sub(log_nu0, torch.logsumexp(_23, [1]))
    _24 = torch.add(Z, torch.unsqueeze(v1, 1))
    u1 = torch.sub(log_mu0, torch.logsumexp(_24, [2]))
    _25 = torch.add(Z, torch.unsqueeze(u1, 2))
    v2 = torch.sub(log_nu0, torch.logsumexp(_25, [1]))
    _26 = torch.add(Z, torch.unsqueeze(v2, 1))
    u2 = torch.sub(log_mu0, torch.logsumexp(_26, [2]))
    _27 = torch.add(Z, torch.unsqueeze(u2, 2))
    v3 = torch.sub(log_nu0, torch.logsumexp(_27, [1]))
    _28 = torch.add(Z, torch.unsqueeze(v3, 1))
    u3 = torch.sub(log_mu0, torch.logsumexp(_28, [2]))
    _29 = torch.add(Z, torch.unsqueeze(u3, 2))
    v4 = torch.sub(log_nu0, torch.logsumexp(_29, [1]))
    _30 = torch.add(Z, torch.unsqueeze(v4, 1))
    u4 = torch.sub(log_mu0, torch.logsumexp(_30, [2]))
    _31 = torch.add(Z, torch.unsqueeze(u4, 2))
    v5 = torch.sub(log_nu0, torch.logsumexp(_31, [1]))
    _32 = torch.add(Z, torch.unsqueeze(v5, 1))
    u5 = torch.sub(log_mu0, torch.logsumexp(_32, [2]))
    _33 = torch.add(Z, torch.unsqueeze(u5, 2))
    v6 = torch.sub(log_nu0, torch.logsumexp(_33, [1]))
    _34 = torch.add(Z, torch.unsqueeze(v6, 1))
    u6 = torch.sub(log_mu0, torch.logsumexp(_34, [2]))
    _35 = torch.add(Z, torch.unsqueeze(u6, 2))
    v7 = torch.sub(log_nu0, torch.logsumexp(_35, [1]))
    _36 = torch.add(Z, torch.unsqueeze(v7, 1))
    u7 = torch.sub(log_mu0, torch.logsumexp(_36, [2]))
    _37 = torch.add(Z, torch.unsqueeze(u7, 2))
    v8 = torch.sub(log_nu0, torch.logsumexp(_37, [1]))
    _38 = torch.add(Z, torch.unsqueeze(v8, 1))
    u8 = torch.sub(log_mu0, torch.logsumexp(_38, [2]))
    _39 = torch.add(Z, torch.unsqueeze(u8, 2))
    v9 = torch.sub(log_nu0, torch.logsumexp(_39, [1]))
    _40 = torch.add(Z, torch.unsqueeze(v9, 1))
    u9 = torch.sub(log_mu0, torch.logsumexp(_40, [2]))
    _41 = torch.add(Z, torch.unsqueeze(u9, 2))
    v10 = torch.sub(log_nu0, torch.logsumexp(_41, [1]))
    _42 = torch.add(Z, torch.unsqueeze(v10, 1))
    u10 = torch.sub(log_mu0, torch.logsumexp(_42, [2]))
    _43 = torch.add(Z, torch.unsqueeze(u10, 2))
    v11 = torch.sub(log_nu0, torch.logsumexp(_43, [1]))
    _44 = torch.add(Z, torch.unsqueeze(v11, 1))
    u11 = torch.sub(log_mu0, torch.logsumexp(_44, [2]))
    _45 = torch.add(Z, torch.unsqueeze(u11, 2))
    v12 = torch.sub(log_nu0, torch.logsumexp(_45, [1]))
    _46 = torch.add(Z, torch.unsqueeze(v12, 1))
    u12 = torch.sub(log_mu0, torch.logsumexp(_46, [2]))
    _47 = torch.add(Z, torch.unsqueeze(u12, 2))
    v13 = torch.sub(log_nu0, torch.logsumexp(_47, [1]))
    _48 = torch.add(Z, torch.unsqueeze(v13, 1))
    u13 = torch.sub(log_mu0, torch.logsumexp(_48, [2]))
    _49 = torch.add(Z, torch.unsqueeze(u13, 2))
    v14 = torch.sub(log_nu0, torch.logsumexp(_49, [1]))
    _50 = torch.add(Z, torch.unsqueeze(v14, 1))
    u14 = torch.sub(log_mu0, torch.logsumexp(_50, [2]))
    _51 = torch.add(Z, torch.unsqueeze(u14, 2))
    v15 = torch.sub(log_nu0, torch.logsumexp(_51, [1]))
    _52 = torch.add(Z, torch.unsqueeze(v15, 1))
    u15 = torch.sub(log_mu0, torch.logsumexp(_52, [2]))
    _53 = torch.add(Z, torch.unsqueeze(u15, 2))
    v16 = torch.sub(log_nu0, torch.logsumexp(_53, [1]))
    _54 = torch.add(Z, torch.unsqueeze(v16, 1))
    u16 = torch.sub(log_mu0, torch.logsumexp(_54, [2]))
    _55 = torch.add(Z, torch.unsqueeze(u16, 2))
    v17 = torch.sub(log_nu0, torch.logsumexp(_55, [1]))
    _56 = torch.add(Z, torch.unsqueeze(v17, 1))
    u17 = torch.sub(log_mu0, torch.logsumexp(_56, [2]))
    _57 = torch.add(Z, torch.unsqueeze(u17, 2))
    v18 = torch.sub(log_nu0, torch.logsumexp(_57, [1]))
    _58 = torch.add(Z, torch.unsqueeze(v18, 1))
    u18 = torch.sub(log_mu0, torch.logsumexp(_58, [2]))
    _59 = torch.add(Z, torch.unsqueeze(u18, 2))
    v19 = torch.sub(log_nu0, torch.logsumexp(_59, [1]))
    _60 = torch.add(Z, torch.unsqueeze(u18, 2))
    Z0 = torch.add(_60, torch.unsqueeze(v19, 1))
    scores3 = torch.sub(Z0, norm)
    _61 = torch.slice(scores3, 0, 0, 9223372036854775807)
    _62 = torch.slice(torch.slice(_61, 1, 0, -1), 2, 0, -1)
    _63, x = torch.max(_62, 2)
    _64 = torch.slice(scores3, 0, 0, 9223372036854775807)
    _65 = torch.slice(torch.slice(_64, 1, 0, -1), 2, 0, -1)
    _66, indices1 = torch.max(_65, 1)
    _67 = ops.prim.NumToTensor(torch.size(x, 1))
    _68 = torch.new_ones(x, [int(_67)], dtype=4, layout=0, device=torch.device("cpu"), pin_memory=False)
    _69 = torch.sub(torch.cumsum(_68, 0), CONSTANTS.c2)
    mutual0 = torch.eq(torch.unsqueeze(_69, 0), torch.gather(indices1, 1, x))
    _70 = ops.prim.NumToTensor(torch.size(indices1, 1))
    _71 = torch.new_ones(indices1, [int(_70)], dtype=4, layout=0, device=torch.device("cpu"), pin_memory=False)
    _72 = torch.sub(torch.cumsum(_71, 0), CONSTANTS.c2)
    mutual1 = torch.eq(torch.unsqueeze(_72, 0), torch.gather(x, 1, indices1))
    _73 = torch.to(CONSTANTS.c3, torch.device("cpu"), 6)
    zero = torch.detach(_73)
    mscores0 = torch.where(mutual0, torch.exp(_63), zero)
    _74 = torch.where(mutual1, torch.gather(mscores0, 1, indices1), zero)
    _75 = torch.gt(mscores0, 0.20000000000000001)
    valid0 = torch.__and__(mutual0, _75)
    valid1 = torch.__and__(mutual1, torch.gather(valid0, 1, indices1))
    _76 = torch.to(CONSTANTS.c4, torch.device("cpu"), 4)
    _77 = torch.where(valid0, x, torch.detach(_76))
    _78 = torch.to(CONSTANTS.c4, torch.device("cpu"), 4)
    _79 = torch.where(valid1, indices1, torch.detach(_78))
    return (_77, _79, mscores0, _74)
class KeypointEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  encoder : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.models.superglue.KeypointEncoder,
    keypoints0: Tensor,
    scores0: Tensor) -> Tensor:
    encoder = self.encoder
    _80 = [torch.transpose(keypoints0, 1, 2), torch.unsqueeze(scores0, 1)]
    input = torch.cat(_80, 1)
    return (encoder).forward(input, )
  def forward1(self: __torch__.models.superglue.KeypointEncoder,
    keypoints1: Tensor,
    scores1: Tensor) -> Tensor:
    encoder = self.encoder
    _81 = [torch.transpose(keypoints1, 1, 2), torch.unsqueeze(scores1, 1)]
    input = torch.cat(_81, 1)
    return (encoder).forward1(input, )
class AttentionalGNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  layers : __torch__.torch.nn.modules.container.___torch_mangle_223.ModuleList
  def forward(self: __torch__.models.superglue.AttentionalGNN,
    value: Tensor,
    value1: Tensor) -> Tuple[Tensor, Tensor]:
    layers = self.layers
    _17 = getattr(layers, "17")
    layers0 = self.layers
    _16 = getattr(layers0, "16")
    layers1 = self.layers
    _15 = getattr(layers1, "15")
    layers2 = self.layers
    _14 = getattr(layers2, "14")
    layers3 = self.layers
    _13 = getattr(layers3, "13")
    layers4 = self.layers
    _12 = getattr(layers4, "12")
    layers5 = self.layers
    _11 = getattr(layers5, "11")
    layers6 = self.layers
    _10 = getattr(layers6, "10")
    layers7 = self.layers
    _9 = getattr(layers7, "9")
    layers8 = self.layers
    _8 = getattr(layers8, "8")
    layers9 = self.layers
    _7 = getattr(layers9, "7")
    layers10 = self.layers
    _6 = getattr(layers10, "6")
    layers11 = self.layers
    _5 = getattr(layers11, "5")
    layers12 = self.layers
    _4 = getattr(layers12, "4")
    layers13 = self.layers
    _3 = getattr(layers13, "3")
    layers14 = self.layers
    _2 = getattr(layers14, "2")
    layers15 = self.layers
    _1 = getattr(layers15, "1")
    layers16 = self.layers
    _0 = getattr(layers16, "0")
    _82 = (_0).forward(value, )
    _83 = (_0).forward1(value1, )
    query = torch.add(value, _82)
    input = torch.add(value1, _83)
    _84 = (_1).forward(query, input, )
    _85 = (_1).forward1(input, query, )
    value2 = torch.add(query, _84)
    value3 = torch.add(input, _85)
    _86 = (_2).forward(value2, )
    _87 = (_2).forward1(value3, )
    query0 = torch.add(value2, _86)
    input0 = torch.add(value3, _87)
    _88 = (_3).forward(query0, input0, )
    _89 = (_3).forward1(input0, query0, )
    value4 = torch.add(query0, _88)
    value5 = torch.add(input0, _89)
    _90 = (_4).forward(value4, )
    _91 = (_4).forward1(value5, )
    query1 = torch.add(value4, _90)
    input1 = torch.add(value5, _91)
    _92 = (_5).forward(query1, input1, )
    _93 = (_5).forward1(input1, query1, )
    value6 = torch.add(query1, _92)
    value7 = torch.add(input1, _93)
    _94 = (_6).forward(value6, )
    _95 = (_6).forward1(value7, )
    query2 = torch.add(value6, _94)
    input2 = torch.add(value7, _95)
    _96 = (_7).forward(query2, input2, )
    _97 = (_7).forward1(input2, query2, )
    value8 = torch.add(query2, _96)
    value9 = torch.add(input2, _97)
    _98 = (_8).forward(value8, )
    _99 = (_8).forward1(value9, )
    query3 = torch.add(value8, _98)
    input3 = torch.add(value9, _99)
    _100 = (_9).forward(query3, input3, )
    _101 = (_9).forward1(input3, query3, )
    value10 = torch.add(query3, _100)
    value11 = torch.add(input3, _101)
    _102 = (_10).forward(value10, )
    _103 = (_10).forward1(value11, )
    query4 = torch.add(value10, _102)
    input4 = torch.add(value11, _103)
    _104 = (_11).forward(query4, input4, )
    _105 = (_11).forward1(input4, query4, )
    value12 = torch.add(query4, _104)
    value13 = torch.add(input4, _105)
    _106 = (_12).forward(value12, )
    _107 = (_12).forward1(value13, )
    query5 = torch.add(value12, _106)
    input5 = torch.add(value13, _107)
    _108 = (_13).forward(query5, input5, )
    _109 = (_13).forward1(input5, query5, )
    value14 = torch.add(query5, _108)
    value15 = torch.add(input5, _109)
    _110 = (_14).forward(value14, )
    _111 = (_14).forward1(value15, )
    query6 = torch.add(value14, _110)
    input6 = torch.add(value15, _111)
    _112 = (_15).forward(query6, input6, )
    _113 = (_15).forward1(input6, query6, )
    value16 = torch.add(query6, _112)
    value17 = torch.add(input6, _113)
    _114 = (_16).forward(value16, )
    _115 = (_16).forward1(value17, )
    query7 = torch.add(value16, _114)
    input7 = torch.add(value17, _115)
    _116 = (_17).forward(query7, input7, )
    _117 = (_17).forward1(input7, query7, )
    input8 = torch.add(query7, _116)
    input9 = torch.add(input7, _117)
    return (input8, input9)
class AttentionalPropagation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  attn : __torch__.models.superglue.MultiHeadedAttention
  mlp : __torch__.torch.nn.modules.container.___torch_mangle_18.Sequential
  def forward(self: __torch__.models.superglue.AttentionalPropagation,
    value: Tensor) -> Tensor:
    mlp = self.mlp
    attn = self.attn
    input = torch.cat([value, (attn).forward(value, )], 1)
    return (mlp).forward(input, )
  def forward1(self: __torch__.models.superglue.AttentionalPropagation,
    value: Tensor) -> Tensor:
    mlp = self.mlp
    attn = self.attn
    input = torch.cat([value, (attn).forward1(value, )], 1)
    return (mlp).forward1(input, )
class MultiHeadedAttention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  merge : __torch__.torch.nn.modules.conv.___torch_mangle_10.Conv1d
  proj : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.models.superglue.MultiHeadedAttention,
    value: Tensor) -> Tensor:
    merge = self.merge
    proj = self.proj
    _2 = getattr(proj, "2")
    proj0 = self.proj
    _1 = getattr(proj0, "1")
    proj1 = self.proj
    _0 = getattr(proj1, "0")
    batch_dim = ops.prim.NumToTensor(torch.size(value, 0))
    _118 = int(batch_dim)
    _119 = int(batch_dim)
    _120 = int(batch_dim)
    _121 = int(batch_dim)
    query = torch.view((_0).forward(value, ), [_121, 64, 4, -1])
    _122 = torch.view((_1).forward(value, ), [_120, 64, 4, -1])
    _123 = torch.view((_2).forward(value, ), [_119, 64, 4, -1])
    _124 = ops.prim.NumToTensor(torch.size(query, 1))
    _125 = torch.einsum("bdhn,bdhm->bhnm", [query, _122])
    input = torch.div(_125, torch.pow(_124, 0.5))
    x = torch.einsum("bhnm,bdhm->bdhn", [torch.softmax(input, -1), _123])
    input10 = torch.view(torch.contiguous(x), [_118, 256, -1])
    return (merge).forward(input10, )
  def forward1(self: __torch__.models.superglue.MultiHeadedAttention,
    value: Tensor) -> Tensor:
    merge = self.merge
    proj = self.proj
    _2 = getattr(proj, "2")
    proj2 = self.proj
    _1 = getattr(proj2, "1")
    proj3 = self.proj
    _0 = getattr(proj3, "0")
    batch_dim = ops.prim.NumToTensor(torch.size(value, 0))
    _126 = int(batch_dim)
    _127 = int(batch_dim)
    _128 = int(batch_dim)
    _129 = int(batch_dim)
    query = torch.view((_0).forward1(value, ), [_129, 64, 4, -1])
    _130 = torch.view((_1).forward1(value, ), [_128, 64, 4, -1])
    _131 = torch.view((_2).forward1(value, ), [_127, 64, 4, -1])
    _132 = ops.prim.NumToTensor(torch.size(query, 1))
    _133 = torch.einsum("bdhn,bdhm->bhnm", [query, _130])
    input = torch.div(_133, torch.pow(_132, 0.5))
    x = torch.einsum("bhnm,bdhm->bdhn", [torch.softmax(input, -1), _131])
    input11 = torch.view(torch.contiguous(x), [_126, 256, -1])
    return (merge).forward1(input11, )
